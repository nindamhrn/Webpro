function UbahBackground() {
	document.body.style.background = "url('image.jpg')";
}
function UbahFont() {
	document.getElementById('telkom').style.fontFamily="cookie";
}
function UbahUkuranFont() {
	document.getElementById('telkom').style.fontSize="50";
}
function UbahWarnaFont() {
	document.getElementById('telkom').style.color="pink";
}
function Hapus() {
	document.getElementById('telkom').remove();
}
function validasi(){
	var nama = document.getElementById('nama').value;
	var email = document.getElementById('email').value;
	var alamat = document.getElementById('alamat').value;
	if(nama != "" && email != "" && alamat != ""){
		alert("Halo "+ nama+ " selamat datang");
	} else{
		alert("Anda Harus Mengisi Data dengan Lengkap");
	}

}